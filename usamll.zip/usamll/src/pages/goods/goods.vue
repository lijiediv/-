<template>
<div>
    goods
</div>
</template>
<script>
export default {
components:{
 },
data () {
 return {
 }
},
methods:{
},
mounted(){
}
}
</script>
<style scoped>
</style>